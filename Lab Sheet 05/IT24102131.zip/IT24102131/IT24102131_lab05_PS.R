setwd("C:\\Users\\user\\Desktop\\IT24102131")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(Delivery_Times)
fix(Delivery_Times)

##2
breaks <- seq(20, 70, length.out = 10)
hist(Delivery_Times$Delivery_Time,breaks = breaks, right = FALSE, main = "Histogram of Delivery Times",xlab = "Delivery Time")

##3
#The distribution of delivery times appears to be approximately symmetric
#Most of the values are concentrated between 35 and 55 minutes, forming a peak around 40–45 minutes, which is likely the mode.

##4
breaks <- seq(20, 70, length.out = 10) 
hist_data <- hist(Delivery_Times$Delivery_Time,breaks = breaks, right = FALSE,plot = FALSE)


cum_freq <- cumsum(hist_data$counts)
plot(hist_data$breaks[-1], cum_freq, type = "o",main = "Cumulative Frequency Polygon (Ogive)", xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency")