setwd("C:\\Users\\user\\Desktop\\IT24102131_Lab07")
#Q1
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#Q2
pexp(2, rate = 1/3)

#Q3
1 - pnorm(130, mean = 100, sd = 15)

#Q4
qnorm(0.95, mean=100,sd=15)
